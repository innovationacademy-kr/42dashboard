export const AUTHPARAM = {
  grant_type: 'authorization_code',
  client_id: '4ff599ee72ee84396cc6b4879ace43e74ed1f593d839df905d0425d2c114fc1a',
  client_secret:
    '9a93f44fbc8249e89ba9edea8d96bd3b04fadeb50cf51681a610430f12438972',
  redirect_uri: 'http://localhost:3000/auth/42/redirection',
  state: 'sStTaATteEe',
};

export const SECRETORKEY = 'huchoi';
export const OAUTHURL =
  'https://api.intra.42.fr/oauth/authorize?client_id=4ff599ee72ee84396cc6b4879ace43e74ed1f593d839df905d0425d2c114fc1a&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fauth%2F42%2Fredirection&response_type=code';

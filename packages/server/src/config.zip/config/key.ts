// const app_api =
//   'https://api.intra.42.fr/oauth/authorize?client_id=b233a450fb76bb08837ba88ba9e0c568a22c3e42f4e48d9aa9f49e819e9a9916&redirect_uri=http%3A%2F%2Flocalhost%3A3000&response_type=code';
// const app_id =
//   'ea2e165515d03c90ddf5c01765248fa934fcbe34322b8b1c7dadac5628202128';
// const app_secret =
//   'f0ae7c076647decc9076ddfd0242b9a464ffb1316985a2fb23e886f1a85e1bac';
// const SPREAD_END_POINT2 = '1jjr1Nr1OTEoCmQhVdAM75LLg1V9ApxtLC8_Hb1Lfqvg';
// const SPREAD_END_POINT = '11plC3Jx-l8muXJCZgSqpB6LQsRld_MooxJthqMH4oKs';
// const SHEET_ID1 = '1538455769';
// const SHEET_ID2 = '78637053';
// const SHEET_ID3 = '2020390618';
// const SHEET_ID4 = '1029115068';

// const SUB_T_ID1 = '758563766'; // 휴학
// const SUB_T_ID2 = '600695573'; // 블랙홀
// const SUB_T_ID3 = '2096611298'; // 과정중단
// const SUB_T_ID4 = '105738183'; // 취업정보
// const SUB_T_ID5 = '105738183'; // 기타취업정보
// const SUB_T_ID6 = '105738183'; // 인턴정보
// const SUB_T_ID7 = '286503938'; // HRD고용보험
// const SUB_T_ID8 = '1288169028'; // 지원금지급기간

// const SUB_C_ID1 = '17811676'; // 지원금지급 2020
// const SUB_C_ID2 = '224875740'; // 지원금지급 2021
// const SUB_C_ID3 = '955948095'; // 지원금지급 2022
// const SUB_C_ID4 = '1061750406'; // 서클
// const SUB_C_ID5 = '96294037'; // 레벨

const app_api =
  'https://api.intra.42.fr/oauth/authorize?client_id=b233a450fb76bb08837ba88ba9e0c568a22c3e42f4e48d9aa9f49e819e9a9916&redirect_uri=http%3A%2F%2Flocalhost%3A3000&response_type=code';
const app_id =
  'ea2e165515d03c90ddf5c01765248fa934fcbe34322b8b1c7dadac5628202128';
const app_secret =
  'f0ae7c076647decc9076ddfd0242b9a464ffb1316985a2fb23e886f1a85e1bac';

const SPREAD_END_POINT = '1T_pUtq70LE9VI1gCP_Nj3rm1tvtsWuVaCslGVlbgHEI';

const MAIN_SHEET = '0. 학사정보관리(main)';

const SUB_LEAVEOFABSENCE_ID = '1. 휴학'; // 휴학
const SUB_BLACKHOLE_ID = '2. 블랙홀'; // 블랙홀
const SUB_INTERRUPTIONOFCOURSE_ID = '3. 과정중단'; // 과정중단
const SUB_LOYALTYMANAGEMENT_ID = '7. 로열티 발생'; //로얄티발생
const SUB_EMPLOYMENTSTATUS_ID = '8. 취업현황'; // 취업현황
const SUB_HRDNETUTILIZE_CONSENT_ID = '8-1. 정보제공동의'; // HRD고용보험 (정보제공동의)
const SUB_HRDNETUTILIZE_ID = '8-2. HRD-Net_data'; // HRD고용보험
const SUB_OTHEREMPLOYMENTSTATUS_ID = '8-3. 기타수집_data'; // 기타수집
const SUB_EDUCATIONFUNDSTATE_ID = '9. 지원금 관리'; // 지원금관리

const SUB_COMPUTATIONFUND2020_ID = '9-1. 지원금지급(2020)'; // 지원금지급 2020
const SUB_COMPUTATIONFUND2021_ID = '9-2. 지원금지급(2021)'; // 지원금지급 2021
const SUB_COMPUTATIONFUND2022_ID = '9-3. 지원금지급(2022)'; // 지원금지급 2022
const SUB_COALITION_API_ID = '4. 코알리숑스코어'; //코알리숑
const SUB_CIRCLE_API_ID = '5. 서클'; // 서클
const SUB_LEVEL_API_ID = '6. 레벨'; // 레벨

export {
  app_api,
  app_id,
  app_secret,
  SPREAD_END_POINT,
  MAIN_SHEET,
  SUB_LEAVEOFABSENCE_ID,
  SUB_BLACKHOLE_ID,
  SUB_INTERRUPTIONOFCOURSE_ID,
  SUB_LOYALTYMANAGEMENT_ID,
  SUB_EMPLOYMENTSTATUS_ID,
  SUB_HRDNETUTILIZE_CONSENT_ID,
  SUB_HRDNETUTILIZE_ID,
  SUB_OTHEREMPLOYMENTSTATUS_ID,
  SUB_EDUCATIONFUNDSTATE_ID,
  SUB_COMPUTATIONFUND2020_ID,
  SUB_COMPUTATIONFUND2021_ID,
  SUB_COMPUTATIONFUND2022_ID,
  SUB_COALITION_API_ID,
  SUB_CIRCLE_API_ID,
  SUB_LEVEL_API_ID,
};
